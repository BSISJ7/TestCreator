package TestCreator.questions.testPanels;

import javax.swing.*;

public abstract class Gradable extends JPanel {
    public abstract float getPointsScored();
}
