package TestCreator.questions.testPanels;


@SuppressWarnings("serial")
public interface GradableFX {
    float getPointsScored();
}
