package TestCreator.questions;

public interface TestableQuestion {

    /**
     */
    void autofillData();
}
