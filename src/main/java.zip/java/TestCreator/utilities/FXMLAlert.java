package TestCreator.utilities;

import javafx.scene.control.Alert;

public class FXMLAlert {
    public static final Alert FXML_ALERT = new Alert(Alert.AlertType.ERROR, "Error loading FXML");
}
